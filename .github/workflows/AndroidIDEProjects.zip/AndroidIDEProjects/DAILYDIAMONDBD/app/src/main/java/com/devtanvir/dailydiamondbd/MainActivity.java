package com.devtanvir.dailydiamondbd;

import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.appcompat.app.AppCompatActivity;

import com.unity3d.ads.IUnityAdsInitializationListener;
import com.unity3d.ads.IUnityAdsShowListener;
import com.unity3d.ads.UnityAds;
import com.unity3d.ads.UnityAdsShowOptions;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    
    // আপনার ইউনিটি ড্যাশবোর্ডের আসল তথ্যগুলো
    private final String UNITY_GAME_ID = "800397660"; 
    private final String REWARDED_ID = "BP_Rewarded_Android";
    private final String INTERSTITIAL_ID = "BP_Interstitial_Android";
    
    // আপনার Daily Diamond BD অ্যাপের লাইভ ওয়েবসাইট লিংক
    private final String WEBSITE_URL = "https://dailydiamondbd.netlify.app"; 

    // টেস্ট করার জন্য true দেওয়া আছে। প্লে-স্টোরে বা ইউজারদের দেওয়ার আগে এটি false করে দেবেন!
    private final boolean TEST_MODE = true; 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ফুল স্ক্রিন WebView তৈরি
        webView = new WebView(this);
        setContentView(webView);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setAllowFileAccess(true);

        webView.setWebViewClient(new WebViewClient());

        // Unity Ads ইনিশিয়ালাইজ করা হচ্ছে
        UnityAds.initialize(getApplicationContext(), UNITY_GAME_ID, TEST_MODE, new IUnityAdsInitializationListener() {
            @Override
            public void onInitializationComplete() {
                // ইনিশিয়ালাইজ সফল
            }

            @Override
            public void onInitializationFailed(UnityAds.UnityAdsInitializationError error, String message) {
                // ইনিশিয়ালাইজ ফেইল
            }
        });

        // ওয়েবসাইটের জাভাস্ক্রিপ্ট বাটনের সাথে অ্যান্ড্রয়েডের কানেকশন ব্রিজ
        webView.addJavascriptInterface(new WebAppInterface(), "AndroidBridge");

        // আপনার ওয়েবসাইট লোড করা হচ্ছে
        webView.loadUrl(WEBSITE_URL);
    }

    public class WebAppInterface {

        // ইন্টারস্টিশিয়াল অ্যাড দেখানোর ফাংশন (জাভাস্ক্রিপ্ট থেকে কল হবে)
        @JavascriptInterface
        public void showUnityInterstitial() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    UnityAds.show(MainActivity.this, INTERSTITIAL_ID);
                }
            });
        }

        // রিওয়ার্ডেড অ্যাড দেখানোর ফাংশন (জাভাস্ক্রিপ্ট থেকে কল হবে)
        @JavascriptInterface
        public void showUnityRewarded() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    UnityAds.show(MainActivity.this, REWARDED_ID, new UnityAdsShowOptions(), new IUnityAdsShowListener() {
                        @Override
                        public void onUnityAdsShowComplete(String placementId, UnityAds.UnityAdsShowCompletionState state) {
                            if (state == UnityAds.UnityAdsShowCompletionState.COMPLETED) {
                                // ইউজার পুরো অ্যাড দেখলে ওয়েবসাইটের onAdRewardedSuccess() ফাংশন রান হবে
                                webView.post(new Runnable() {
                                    @Override
                                    public void run() {
                                        webView.evaluateJavascript("onAdRewardedSuccess();", null);
                                    }
                                });
                            }
                        }

                        @Override
                        public void onUnityAdsShowFailure(String placementId, UnityAds.UnityAdsShowError error, String message) {}

                        @Override
                        public void onUnityAdsShowStart(String placementId) {}

                        @Override
                        public void onUnityAdsShowClick(String placementId) {}
                    });
                }
            });
        }
    }

    // ফোনের ব্যাক বাটনে চাপ দিলে যেন অ্যাপ থেকে বের না হয়ে ওয়েবসাইটের আগের পেজে যায়
    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
} কে